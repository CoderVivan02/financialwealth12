export interface FinancialGoal {
  name: string;
  targetAmount: number;
  currentSavings: number;
  targetDate?: Date;
}

export type RiskPreference = 'low' | 'medium' | 'high';

export interface ProjectionResult {
  monthsToGoal: number;
  suggestedMonthlyContribution: number;
  projectedReturns: number;
  alternativeScenarios: AlternativeScenario[];
}

export interface AlternativeScenario {
  additionalContribution: number;
  monthsReduced: number;
  newProjectedReturns: number;
}

export interface PortfolioAllocation {
  stocks: number;
  bonds: number;
  cash: number;
  crypto?: number;
  gold?: number;
}

export interface DailyTransaction {
  id: string;
  date: Date;
  amount: number;
  category: string;
  type: 'income' | 'expense';
  description: string;
}

export interface MarketData {
  symbol: string;
  name: string;
  price: number;
  change: number;
  changePercent: number;
}

export interface FinancialAdvice {
  id: string;
  advisor: string;
  title: string;
  content: string;
  date: Date;
  category: string;
}