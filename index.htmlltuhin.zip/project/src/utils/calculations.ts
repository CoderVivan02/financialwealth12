export const calculateProjection = (
  targetAmount: number,
  currentSavings: number,
  monthlySavings: number,
  riskPreference: 'low' | 'medium' | 'high'
): { months: number; projectedAmount: number; alternativeScenarios: AlternativeScenario[] } => {
  // Enhanced return rates based on risk preference
  const annualReturnRates = {
    low: 0.04,
    medium: 0.08,
    high: 0.12
  };

  const monthlyRate = annualReturnRates[riskPreference] / 12;
  let currentAmount = currentSavings;
  let months = 0;

  while (currentAmount < targetAmount && months < 600) { // 50-year cap
    currentAmount = currentAmount * (1 + monthlyRate) + monthlySavings;
    months++;
  }

  // Calculate alternative scenarios
  const alternativeScenarios = [
    calculateAlternativeScenario(targetAmount, currentSavings, monthlySavings * 1.1, monthlyRate), // 10% more
    calculateAlternativeScenario(targetAmount, currentSavings, monthlySavings * 1.2, monthlyRate), // 20% more
  ];

  return {
    months,
    projectedAmount: currentAmount,
    alternativeScenarios
  };
};

const calculateAlternativeScenario = (
  targetAmount: number,
  currentSavings: number,
  increasedMonthlySavings: number,
  monthlyRate: number
): AlternativeScenario => {
  let currentAmount = currentSavings;
  let months = 0;

  while (currentAmount < targetAmount && months < 600) {
    currentAmount = currentAmount * (1 + monthlyRate) + increasedMonthlySavings;
    months++;
  }

  return {
    additionalContribution: increasedMonthlySavings,
    monthsReduced: months,
    newProjectedReturns: currentAmount
  };
};

export const getSuggestedPortfolio = (riskPreference: 'low' | 'medium' | 'high'): PortfolioAllocation => {
  const portfolios = {
    low: { stocks: 25, bonds: 55, cash: 15, gold: 5 },
    medium: { stocks: 50, bonds: 30, cash: 10, gold: 5, crypto: 5 },
    high: { stocks: 70, bonds: 15, cash: 5, gold: 5, crypto: 5 }
  };

  return portfolios[riskPreference];
};