import React, { useState } from 'react';
import { GoalForm } from './components/GoalForm';
import { ProjectionResults } from './components/ProjectionResults';
import { DailyFinanceTracker } from './components/DailyFinanceTracker';
import { MarketOverview } from './components/MarketOverview';
import { AdvisorSection } from './components/AdvisorSection';
import { Header } from './components/Header';
import { SubscriptionPlans } from './components/SubscriptionPlans';
import { calculateProjection, getSuggestedPortfolio } from './utils/calculations';
import { FinancialGoal, RiskPreference, ProjectionResult, DailyTransaction, MarketData, FinancialAdvice } from './types';
import { Coins } from 'lucide-react';

// Sample market data
const sampleMarketData: MarketData[] = [
  { symbol: 'AAPL', name: 'Apple Inc.', price: 173.45, change: 2.31, changePercent: 1.35 },
  { symbol: 'MSFT', name: 'Microsoft Corp.', price: 415.32, change: -1.23, changePercent: -0.30 },
  { symbol: 'GOOGL', name: 'Alphabet Inc.', price: 141.78, change: 0.87, changePercent: 0.62 },
  { symbol: 'AMZN', name: 'Amazon.com Inc.', price: 178.22, change: 3.45, changePercent: 1.97 },
  { symbol: 'NVDA', name: 'NVIDIA Corp.', price: 788.17, change: 15.32, changePercent: 1.98 },
  { symbol: 'META', name: 'Meta Platforms Inc.', price: 485.58, change: -2.34, changePercent: -0.48 }
];

// Sample financial advice
const sampleAdvice: FinancialAdvice[] = [
  {
    id: '1',
    advisor: 'Sarah Johnson, CFA',
    title: 'Market Volatility Strategy',
    content: 'In times of market volatility, maintaining a diversified portfolio is crucial. Consider rebalancing your portfolio quarterly and focus on quality stocks with strong fundamentals.',
    date: new Date(),
    category: 'Investment Strategy'
  },
  {
    id: '2',
    advisor: 'Michael Chen, CPA',
    title: 'Tax Planning Tips',
    content: 'Start your tax planning early. Maximize your retirement contributions and consider tax-loss harvesting to optimize your investment returns.',
    date: new Date(),
    category: 'Tax Planning'
  }
];

function App() {
  const [projectionResult, setProjectionResult] = useState<ProjectionResult | null>(null);
  const [portfolio, setPortfolio] = useState<ReturnType<typeof getSuggestedPortfolio> | null>(null);
  const [transactions, setTransactions] = useState<DailyTransaction[]>([]);

  const handleSubmit = (
    goal: FinancialGoal,
    monthlySavings: number,
    risk: RiskPreference
  ) => {
    const projection = calculateProjection(
      goal.targetAmount,
      goal.currentSavings,
      monthlySavings,
      risk
    );

    setProjectionResult({
      monthsToGoal: projection.months,
      suggestedMonthlyContribution: monthlySavings,
      projectedReturns: projection.projectedAmount,
      alternativeScenarios: projection.alternativeScenarios
    });

    setPortfolio(getSuggestedPortfolio(risk));
  };

  const handleAddTransaction = (transaction: Omit<DailyTransaction, 'id'>) => {
    const newTransaction: DailyTransaction = {
      ...transaction,
      id: Math.random().toString(36).substr(2, 9)
    };
    setTransactions([newTransaction, ...transactions]);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="text-center mb-12">
          <div className="flex justify-center mb-4">
            <Coins className="h-12 w-12 text-indigo-600" />
          </div>
          <h1 className="text-4xl font-bold text-gray-900 mb-4">
            Future Wealth Planner
          </h1>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            See your future, own your dreams. Plan your financial journey with our smart calculator.
            Set your goals, define your risk tolerance, and get personalized investment recommendations.
          </p>
        </div>

        <div className="space-y-8">
          <div className="bg-white rounded-lg shadow-lg p-6 mb-8">
            <GoalForm onSubmit={handleSubmit} />
          </div>

          {projectionResult && portfolio && (
            <ProjectionResults
              result={projectionResult}
              portfolio={portfolio}
            />
          )}

          <DailyFinanceTracker
            onAddTransaction={handleAddTransaction}
            transactions={transactions}
          />

          <MarketOverview marketData={sampleMarketData} />

          <AdvisorSection advice={sampleAdvice} />

          <SubscriptionPlans />
        </div>
      </div>
    </div>
  );
}

export default App;