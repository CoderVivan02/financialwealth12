import React from 'react';
import { MarketData } from '../types';
import { TrendingUp, TrendingDown } from 'lucide-react';

interface MarketOverviewProps {
  marketData: MarketData[];
}

export const MarketOverview: React.FC<MarketOverviewProps> = ({ marketData }) => {
  return (
    <div className="bg-white rounded-lg shadow-lg p-6">
      <h2 className="text-2xl font-bold text-gray-900 mb-6">Market Overview</h2>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {marketData.map((item) => (
          <div
            key={item.symbol}
            className="p-4 border border-gray-200 rounded-lg hover:shadow-md transition-shadow"
          >
            <div className="flex justify-between items-start">
              <div>
                <h3 className="font-medium text-gray-900">{item.symbol}</h3>
                <p className="text-sm text-gray-500">{item.name}</p>
              </div>
              <div className="text-right">
                <p className="font-medium text-gray-900">${item.price.toFixed(2)}</p>
                <p
                  className={`text-sm flex items-center ${
                    item.change >= 0 ? 'text-green-600' : 'text-red-600'
                  }`}
                >
                  {item.change >= 0 ? (
                    <TrendingUp className="h-4 w-4 mr-1" />
                  ) : (
                    <TrendingDown className="h-4 w-4 mr-1" />
                  )}
                  {item.change >= 0 ? '+' : ''}
                  {item.changePercent.toFixed(2)}%
                </p>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};