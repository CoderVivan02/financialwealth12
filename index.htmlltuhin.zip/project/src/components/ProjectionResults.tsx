import React from 'react';
import { ProjectionResult, PortfolioAllocation } from '../types';
import { PieChart, Wallet, Calendar, TrendingUp, AlertCircle } from 'lucide-react';

interface ProjectionResultsProps {
  result: ProjectionResult;
  portfolio: PortfolioAllocation;
}

export const ProjectionResults: React.FC<ProjectionResultsProps> = ({ result, portfolio }) => {
  const years = Math.floor(result.monthsToGoal / 12);
  const months = result.monthsToGoal % 12;

  return (
    <div className="bg-white rounded-lg shadow-lg p-6 max-w-2xl mx-auto mt-8">
      <h2 className="text-2xl font-bold text-gray-900 mb-6">Your Financial Roadmap</h2>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="space-y-4">
          <div className="flex items-center space-x-3">
            <Calendar className="h-6 w-6 text-indigo-600" />
            <div>
              <h3 className="text-lg font-medium text-gray-900">Time to Goal</h3>
              <p className="text-gray-600">
                {years > 0 && `${years} years`} {months > 0 && `${months} months`}
              </p>
            </div>
          </div>

          <div className="flex items-center space-x-3">
            <Wallet className="h-6 w-6 text-indigo-600" />
            <div>
              <h3 className="text-lg font-medium text-gray-900">Monthly Contribution</h3>
              <p className="text-gray-600">
                ${result.suggestedMonthlyContribution.toLocaleString()}
              </p>
            </div>
          </div>

          <div className="flex items-center space-x-3">
            <TrendingUp className="h-6 w-6 text-indigo-600" />
            <div>
              <h3 className="text-lg font-medium text-gray-900">Projected Returns</h3>
              <p className="text-gray-600">
                ${result.projectedReturns.toLocaleString()}
              </p>
            </div>
          </div>

          {result.alternativeScenarios?.length > 0 && (
            <div className="mt-6 p-4 bg-indigo-50 rounded-lg">
              <div className="flex items-center space-x-2 mb-3">
                <AlertCircle className="h-5 w-5 text-indigo-600" />
                <h4 className="text-sm font-medium text-indigo-900">Alternative Scenarios</h4>
              </div>
              {result.alternativeScenarios.map((scenario, index) => (
                <div key={index} className="text-sm text-indigo-800 mt-2">
                  Increase monthly savings to ${scenario.additionalContribution.toLocaleString()} to reach your goal {Math.floor(scenario.monthsReduced / 12)} years {scenario.monthsReduced % 12} months sooner
                </div>
              ))}
            </div>
          )}
        </div>

        <div className="space-y-4">
          <div className="flex items-center space-x-3 mb-4">
            <PieChart className="h-6 w-6 text-indigo-600" />
            <h3 className="text-lg font-medium text-gray-900">Suggested Portfolio</h3>
          </div>
          
          <div className="space-y-2">
            {Object.entries(portfolio).map(([asset, percentage]) => (
              <div key={asset}>
                <div className="flex justify-between">
                  <span className="text-gray-600 capitalize">{asset}</span>
                  <span className="font-medium">{percentage}%</span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div
                    className={`h-2 rounded-full ${
                      asset === 'stocks' ? 'bg-indigo-600' :
                      asset === 'bonds' ? 'bg-green-500' :
                      asset === 'cash' ? 'bg-blue-500' :
                      asset === 'crypto' ? 'bg-purple-500' :
                      'bg-yellow-500'
                    }`}
                    style={{ width: `${percentage}%` }}
                  />
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};