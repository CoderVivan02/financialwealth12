import React from 'react';
import { Check, Star } from 'lucide-react';

const plans = [
  {
    name: 'Basic',
    price: 0,
    features: [
      'Basic financial goal tracking',
      'Simple investment calculator',
      'Market overview',
      'Daily transaction tracking'
    ],
    buttonText: 'Get Started',
    highlighted: false
  },
  {
    name: 'Pro',
    price: 9.99,
    features: [
      'All Basic features',
      'Advanced portfolio analytics',
      'Personalized investment advice',
      'Real-time market alerts',
      'Priority customer support'
    ],
    buttonText: 'Try Pro',
    highlighted: true
  },
  {
    name: 'Enterprise',
    price: 29.99,
    features: [
      'All Pro features',
      'Dedicated financial advisor',
      'Custom investment strategies',
      'Team collaboration',
      'API access',
      'White-label options'
    ],
    buttonText: 'Contact Sales',
    highlighted: false
  }
];

export const SubscriptionPlans: React.FC = () => {
  return (
    <div className="bg-white rounded-lg shadow-lg p-6">
      <div className="text-center mb-8">
        <h2 className="text-3xl font-bold text-gray-900">Choose Your Plan</h2>
        <p className="mt-4 text-lg text-gray-600">
          Select the perfect plan for your financial journey
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        {plans.map((plan) => (
          <div
            key={plan.name}
            className={`rounded-lg p-8 ${
              plan.highlighted
                ? 'ring-2 ring-indigo-600 shadow-xl'
                : 'border border-gray-200'
            }`}
          >
            {plan.highlighted && (
              <div className="flex justify-center">
                <span className="inline-flex items-center px-3 py-1 rounded-full text-sm font-medium bg-indigo-100 text-indigo-800">
                  <Star className="h-4 w-4 mr-1" />
                  Most Popular
                </span>
              </div>
            )}
            <div className="text-center">
              <h3 className="text-2xl font-bold text-gray-900 mt-4">{plan.name}</h3>
              <div className="mt-4">
                <span className="text-4xl font-bold">${plan.price}</span>
                <span className="text-gray-500">/month</span>
              </div>
            </div>

            <ul className="mt-8 space-y-4">
              {plan.features.map((feature) => (
                <li key={feature} className="flex items-start">
                  <Check className="h-5 w-5 text-green-500 mr-2 flex-shrink-0" />
                  <span className="text-gray-600">{feature}</span>
                </li>
              ))}
            </ul>

            <button
              className={`mt-8 w-full py-3 px-4 rounded-md text-sm font-semibold focus:outline-none focus:ring-2 focus:ring-offset-2 ${
                plan.highlighted
                  ? 'bg-indigo-600 text-white hover:bg-indigo-700 focus:ring-indigo-500'
                  : 'bg-indigo-50 text-indigo-700 hover:bg-indigo-100 focus:ring-indigo-500'
              }`}
            >
              {plan.buttonText}
            </button>
          </div>
        ))}
      </div>
    </div>
  );
};