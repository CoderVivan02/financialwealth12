import React from 'react';
import { FinancialAdvice } from '../types';
import { UserCheck, Calendar } from 'lucide-react';
import { format } from 'date-fns';

interface AdvisorSectionProps {
  advice: FinancialAdvice[];
}

export const AdvisorSection: React.FC<AdvisorSectionProps> = ({ advice }) => {
  return (
    <div className="bg-white rounded-lg shadow-lg p-6">
      <h2 className="text-2xl font-bold text-gray-900 mb-6">Expert Financial Advice</h2>
      
      <div className="space-y-6">
        {advice.map((item) => (
          <div key={item.id} className="border-b border-gray-200 pb-6 last:border-b-0">
            <div className="flex items-start justify-between mb-4">
              <div className="flex items-center">
                <UserCheck className="h-6 w-6 text-indigo-600 mr-2" />
                <div>
                  <h3 className="font-medium text-gray-900">{item.advisor}</h3>
                  <p className="text-sm text-gray-500">{item.category}</p>
                </div>
              </div>
              <div className="flex items-center text-sm text-gray-500">
                <Calendar className="h-4 w-4 mr-1" />
                {format(new Date(item.date), 'MMM d, yyyy')}
              </div>
            </div>
            
            <h4 className="text-lg font-medium text-gray-900 mb-2">{item.title}</h4>
            <p className="text-gray-600">{item.content}</p>
          </div>
        ))}
      </div>
    </div>
  );
};