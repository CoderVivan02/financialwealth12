import React, { useState } from 'react';
import { DailyTransaction } from '../types';
import { PlusCircle, DollarSign, Tag, Calendar } from 'lucide-react';
import { format } from 'date-fns';

interface DailyFinanceTrackerProps {
  onAddTransaction: (transaction: Omit<DailyTransaction, 'id'>) => void;
  transactions: DailyTransaction[];
}

export const DailyFinanceTracker: React.FC<DailyFinanceTrackerProps> = ({
  onAddTransaction,
  transactions
}) => {
  const [amount, setAmount] = useState('');
  const [category, setCategory] = useState('');
  const [description, setDescription] = useState('');
  const [type, setType] = useState<'income' | 'expense'>('expense');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onAddTransaction({
      date: new Date(),
      amount: Number(amount),
      category,
      type,
      description
    });
    setAmount('');
    setCategory('');
    setDescription('');
  };

  const categories = ['Food', 'Transport', 'Shopping', 'Bills', 'Entertainment', 'Other'];

  return (
    <div className="bg-white rounded-lg shadow-lg p-6">
      <h2 className="text-2xl font-bold text-gray-900 mb-6">Daily Finance Tracker</h2>

      <form onSubmit={handleSubmit} className="space-y-4 mb-8">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700">Amount</label>
            <div className="mt-1 relative rounded-md shadow-sm">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center">
                <DollarSign className="h-5 w-5 text-gray-400" />
              </div>
              <input
                type="number"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                className="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md"
                required
              />
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700">Category</label>
            <select
              value={category}
              onChange={(e) => setCategory(e.target.value)}
              className="mt-1 block w-full pl-3 pr-10 py-2 border border-gray-300 rounded-md"
              required
            >
              <option value="">Select category</option>
              {categories.map((cat) => (
                <option key={cat} value={cat}>{cat}</option>
              ))}
            </select>
          </div>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700">Description</label>
          <input
            type="text"
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            className="mt-1 block w-full pl-3 pr-10 py-2 border border-gray-300 rounded-md"
            required
          />
        </div>

        <div className="flex space-x-4">
          <label className="inline-flex items-center">
            <input
              type="radio"
              value="expense"
              checked={type === 'expense'}
              onChange={(e) => setType(e.target.value as 'expense')}
              className="form-radio h-4 w-4 text-indigo-600"
            />
            <span className="ml-2">Expense</span>
          </label>
          <label className="inline-flex items-center">
            <input
              type="radio"
              value="income"
              checked={type === 'income'}
              onChange={(e) => setType(e.target.value as 'income')}
              className="form-radio h-4 w-4 text-indigo-600"
            />
            <span className="ml-2">Income</span>
          </label>
        </div>

        <button
          type="submit"
          className="w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700"
        >
          <PlusCircle className="h-5 w-5 mr-2" />
          Add Transaction
        </button>
      </form>

      <div className="space-y-4">
        <h3 className="text-lg font-medium text-gray-900">Recent Transactions</h3>
        <div className="space-y-2">
          {transactions.map((transaction) => (
            <div
              key={transaction.id}
              className={`p-4 rounded-lg ${
                transaction.type === 'income' ? 'bg-green-50' : 'bg-red-50'
              }`}
            >
              <div className="flex justify-between items-center">
                <div>
                  <p className="font-medium text-gray-900">{transaction.description}</p>
                  <p className="text-sm text-gray-500">
                    <span className="inline-flex items-center">
                      <Tag className="h-4 w-4 mr-1" />
                      {transaction.category}
                    </span>
                    <span className="mx-2">•</span>
                    <span className="inline-flex items-center">
                      <Calendar className="h-4 w-4 mr-1" />
                      {format(new Date(transaction.date), 'MMM d, yyyy')}
                    </span>
                  </p>
                </div>
                <span
                  className={`font-medium ${
                    transaction.type === 'income' ? 'text-green-600' : 'text-red-600'
                  }`}
                >
                  {transaction.type === 'income' ? '+' : '-'}${transaction.amount}
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};